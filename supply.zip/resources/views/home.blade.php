@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Information page</div>

                    <div class="panel-body">
                        <div class="alert alert-success">
                            Your registration has been completed successfully.
                        </div>

                        You will be notified by email after your account has been approved by your administrator.
                        <br>
                        Thank you!!!
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
