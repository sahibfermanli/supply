<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
      <div>
          <h1>Ana səhifə</h1>
          <p>Tezliklə bildirişlər burada olacaq...</p>
      </div>
        
            
                
                    
                    
                    
                    
                
            
        
        <div class="clearfix"></div>
    </div>
    <!-- /page content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>