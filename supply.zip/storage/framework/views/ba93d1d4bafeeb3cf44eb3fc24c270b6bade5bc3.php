<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left" style="width: 100%; !important;">
                    <h3 style="display: inline-block;"> Purchases</h3>
                </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_content">
                            <div class="table-responsive">
                                <div>
                                    <?php echo $purchases->links();; ?>

                                </div>
                                <table class="table table-bordered">
                                    <thead>
                                    <tr class="headings">
                                        <th class="column-title">#</th>
                                        <th class="column-title" style="min-width: 200px;">Sifarişçi </th>
                                        <th class="column-title" style="min-width: 100px;">Malın adı </th>
                                        <th class="column-title" style="min-width: 150px;">Marka </th>
                                        <th class="column-title" style="min-width: 100px;">Model </th>
                                        <th class="column-title">Miqdar </th>
                                        <th class="column-title">Ölçü vahidi </th>
                                        <th class="column-title">Qiymət </th>
                                        <th class="column-title">Ümumi qiymət </th>
                                        <th class="column-title">Yaradılma tarixi </th>
                                        <th class="column-title">Şirkət </th>
                                        
                                        <th class="column-title">Hesab </th>
                                        <th class="column-title">Qaime </th>
                                        <th class="column-title">Hüquq </th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php
                                        $row = 1;
                                    ?>
                                    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $date = date('d.m.Y', strtotime($purchase->created_at));
                                            //deadline
                                            $dead_line = $purchase->deadline;
                                            $difference = intval(abs(strtotime($current_date)-strtotime($dead_line))/86400);
                                            $color = 'white';

                                            foreach ($deadlines as $deadline) {
                                              if ($difference <= $deadline->deadline) {
                                                $color = $deadline->color;
                                                break;
                                              }
                                            }
                                        ?>
                                        <tr class="even pointer" id="row_<?php echo e($row); ?>">
                                            <td style="background-color: <?php echo e($color); ?>;"><?php echo e($row); ?></td>
                                            <td><?php echo e($purchase->name); ?> <?php echo e($purchase->surname); ?> , <?php echo e($purchase->Department); ?></td>
                                            <td><?php echo e($purchase->Product); ?></td>
                                            <td><?php echo e($purchase->Brend); ?></td>
                                            <td><?php echo e($purchase->Model); ?></td>
                                            <td><?php echo e($purchase->pcs); ?></td>
                                            <td><?php echo e($purchase->Unit); ?></td>
                                            <td><?php echo e($purchase->cost); ?></td>
                                            <td><?php echo e($purchase->total_cost); ?></td>
                                            <td><?php echo e($date); ?></td>
                                            <td title="<?php echo e($purchase->phone); ?> , <?php echo e($purchase->address); ?>"><?php echo e($purchase->company); ?></td>
                                            
                                            <td>
                                                <?php if(isset($purchase->account_id)): ?>
                                                    <a title="<?php echo e($purchase->account_date); ?>" class="btn btn-success btn-xs" title="<?php echo e($purchase->account_date); ?>" target="_blank" href="<?php echo e($purchase->account_doc); ?>"><i class="fa fa-download"></i> <?php echo e($purchase->account_no); ?></a>
                                                <?php else: ?>
                                                    <span title="Heç bir hesaba əlavə edilməyib" disabled="true" class="btn btn-success btn-xs" style="background-color: #b6a338; border-color: #b6a338;"><i class="fa fa-download"></i></span>
                                                <?php endif; ?>
                                            </td>
                                            <td style="min-width: 150px;">
                                                <?php if(isset($purchase->qaime_doc)): ?>
                                                    <a href="<?php echo e($purchase->qaime_doc); ?>" title="<?php echo e($purchase->qaime_date); ?>" class="btn btn-success btn-xs" style="background-color: #1b6d85; border-color: #1b6d85;"><i class="fa fa-download"></i> <?php echo e($purchase->qaime_no); ?></a>
                                                <?php else: ?>
                                                    <span title="Qaiməni yoxdur" disabled="true" class="btn btn-success btn-xs" style="background-color: #b6a338; border-color: #b6a338;"><i class="fa fa-download"></i></span>
                                                <?php endif; ?>

                                                <?php if($purchase->account_id == null): ?>
                                                    <span title="Qaimə yüklə" onclick="upload_qaime(<?php echo e($purchase->id); ?>);" class="btn btn-success btn-xs add-qaime"><i class="fa fa-upload"></i></span>
                                                <?php else: ?>
                                                    <span disabled="true" title="Düymə deaktivdir" class="btn btn-warning btn-xs"><i class="fa fa-upload"></i></span>
                                                <?php endif; ?>
                                            </td>

                                            <?php if(isset($purchase->lawyer_doc)): ?>
                                                <td title="<?php echo e($purchase->lawyer_confirm_at); ?>"><a href="<?php echo e($purchase->lawyer_doc); ?>" class="btn btn-success btn-xs"><i class="fa fa-download"></i></a></td>
                                            <?php else: ?>
                                                <td title="Fayl yoxdur"><span disabled="true" class="btn btn-success btn-xs"><i class="fa fa-download"></i></span></td>
                                            <?php endif; ?>

                                        </tr>
                                        <?php
                                            $row++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div>
                                    <?php echo $purchases->links();; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="add-qaime" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Qaiməni yüklə</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="type" value="add_qaime">
                        <div id="purchase_id_div"></div>
                        <?php echo e(csrf_field()); ?>

                        <input type="file" name="file" class="form-control" style="width: 30%; display: inline-block;" required>
                        <input type="text" name="qaime_no" class="form-control" style="width: 30%; display: inline-block;" required placeholder="qaimənin nömrəsi">
                        <button type="submit" class="btn btn-success" style="display: inline-block;"><i class="fa fa-save"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/sweetalert2.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/js/jquery.form.min.js"></script>
    <script src="/js/jquery.validate.min.js"></script>
    <script src="/js/sweetalert2.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('form').validate();
            $('form').ajaxForm({
                beforeSubmit:function () {
                    //loading
                    swal ({
                        title: '<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i><span class="sr-only">Əməliyyat aparılır...</span>',
                        text: 'Əməliyyat aparılır, xaiş olunur gözləyin...',
                        showConfirmButton: false
                    });
                },
                success:function (response) {
                    swal(
                        response.title,
                        response.content,
                        response.case
                    );
                    if (response.case === 'success') {
                        location.reload();
                    }
                }
            });
        });

        //upload qaime
        function upload_qaime(purchase_id) {
            $('#purchase_id_div').html('<input type="hidden" name="purchase_id" value="' + purchase_id + '">');
        }

        //add modal
        $(document).on('click', '.add-qaime', function() {
            $('#add-qaime').modal('show');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>