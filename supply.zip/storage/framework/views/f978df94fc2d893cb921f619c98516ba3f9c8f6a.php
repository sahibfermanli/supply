<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="<?php echo e($name); ?>"><?php echo e($label); ?>

    </label>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <?php echo e(Form::password($name, $value, array_merge(['class' => 'form-control col-md-7 col-xs-12'], array_merge(['id'=>$name])))); ?>

    </div>
</div>