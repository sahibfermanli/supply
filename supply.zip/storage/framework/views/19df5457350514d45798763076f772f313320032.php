<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left" style="width: 100%; !important;">
                    <h3 style="display: inline-block;"> Purchases</h3>
                </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_content">
                            <div class="table-responsive">
                                <div>
                                    <?php echo $purchases->links();; ?>

                                </div>
                                <table class="table table-bordered">
                                    <thead>
                                    <tr class="headings">
                                        <th class="column-title">#</th>
                                        <th class="column-title">Malın adı </th>
                                        <th class="column-title">Marka </th>
                                        <th class="column-title">Model </th>
                                        <th class="column-title">Miqdar </th>
                                        <th class="column-title">Ölçü vahidi </th>
                                        <th class="column-title">Qiymət </th>
                                        <th class="column-title">Ümumi qiymət </th>
                                        <th class="column-title">Yaradılma tarixi </th>
                                        <th class="column-title">Sirket </th>
                                        <th class="column-title">Təslimatçı </th>
                                        <th class="column-title">Ödəniş tarixi </th>
                                        <th class="column-title">Hesab doc. </th>
                                        <th class="column-title">Qaime doc. </th>
                                        <th class="column-title">AWB_Akt doc. </th>
                                        <th class="column-title">Icraci doc. </th>
                                        <th class="column-title">Verilib MHIS </th>
                                        <th class="column-title">Verilib MS </th>
                                        
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php
                                        $row = 1;
                                    ?>
                                    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $date = date('d.m.Y', strtotime($purchase->created_at));
                                            //deadline
                                            $dead_line = $purchase->deadline;
                                            $difference = intval(abs(strtotime($current_date)-strtotime($dead_line))/86400);
                                            $color = 'white';

                                            foreach ($deadlines as $deadline) {
                                              if ($difference <= $deadline->deadline) {
                                                $color = $deadline->color;
                                                break;
                                              }
                                            }
                                        ?>
                                        <tr class="even pointer" id="row_<?php echo e($row); ?>">
                                            <td style="background-color: <?php echo e($color); ?>;"><?php echo e($row); ?></td>
                                            <td><?php echo e($purchase->Product); ?></td>
                                            <td><?php echo e($purchase->Brend); ?></td>
                                            <td><?php echo e($purchase->Model); ?></td>
                                            <td><?php echo e($purchase->pcs); ?></td>
                                            <td><?php echo e($purchase->Unit); ?></td>
                                            <td><?php echo e($purchase->cost); ?></td>
                                            <td><?php echo e($purchase->total_cost); ?></td>
                                            <td><?php echo e($date); ?></td>
                                            <td title="<?php echo e($purchase->phone); ?> , <?php echo e($purchase->address); ?>"><?php echo e($purchase->company); ?></td>
                                            <td title="<?php echo e($purchase->delivery_date); ?>"><?php echo e($purchase->name); ?> <?php echo e($purchase->surname); ?></td>
                                            <td><?php echo e($purchase->odenish_date); ?></td>
                                            <?php if(isset($purchase->hesab_doc)): ?>
                                                <td title="<?php echo e($purchase->hesab_doc_date); ?>"><a href="<?php echo e($purchase->hesab_doc); ?>" class="btn btn-success btn-xs"><i class="fa fa-download"></i></a></td>
                                            <?php else: ?>
                                                <td title="<?php echo e($purchase->hesab_doc_date); ?>"><span disabled="true" class="btn btn-success btn-xs"><i class="fa fa-download"></i></span></td>
                                            <?php endif; ?>
                                            <?php if(isset($purchase->qaime_doc)): ?>
                                                <td title="<?php echo e($purchase->qaime_doc_date); ?>"><a href="<?php echo e($purchase->qaime_doc); ?>" class="btn btn-success btn-xs"><i class="fa fa-download"></i></a></td>
                                            <?php else: ?>
                                                <td title="<?php echo e($purchase->qaime_doc_date); ?>"><span disabled="true" class="btn btn-success btn-xs"><i class="fa fa-download"></i></span></td>
                                            <?php endif; ?>
                                            <?php if(isset($purchase->AWB_Akt_doc)): ?>
                                                <td title="<?php echo e($purchase->AWB_Akt_doc_date); ?>"><a href="<?php echo e($purchase->AWB_Akt_doc); ?>" class="btn btn-success btn-xs"><i class="fa fa-download"></i></a></td>
                                            <?php else: ?>
                                                <td title="<?php echo e($purchase->AWB_Akt_doc_date); ?>"><span disabled="true" class="btn btn-success btn-xs"><i class="fa fa-download"></i></span></td>
                                            <?php endif; ?>
                                            <?php if(isset($purchase->icrachi_doc)): ?>
                                                <td title="<?php echo e($purchase->icrachi_doc_date); ?>"><a href="<?php echo e($purchase->icrachi_doc); ?>" class="btn btn-success btn-xs"><i class="fa fa-download"></i></a></td>
                                            <?php else: ?>
                                                <td title="<?php echo e($purchase->icrachi_doc_date); ?>"><span disabled="true" class="btn btn-success btn-xs"><i class="fa fa-download"></i></span></td>
                                            <?php endif; ?>
                                            <?php if(isset($purchase->Verilib_MHIS)): ?>
                                                <td title="<?php echo e($purchase->Verilib_MHIS_date); ?>"><a href="<?php echo e($purchase->Verilib_MHIS); ?>" class="btn btn-success btn-xs"><i class="fa fa-download"></i></a></td>
                                            <?php else: ?>
                                                <td title="<?php echo e($purchase->Verilib_MHIS_date); ?>"><span disabled="true" class="btn btn-success btn-xs"><i class="fa fa-download"></i></span></td>
                                            <?php endif; ?>
                                            <?php if(isset($purchase->Verilib_MS)): ?>
                                                <td title="<?php echo e($purchase->Verilib_MS_date); ?>"><a href="<?php echo e($purchase->Verilib_MS); ?>" class="btn btn-success btn-xs"><i class="fa fa-download"></i></a></td>
                                            <?php else: ?>
                                                <td title="<?php echo e($purchase->Verilib_MS_date); ?>"><span disabled="true" class="btn btn-success btn-xs"><i class="fa fa-download"></i></span></td>
                                            <?php endif; ?>
                                            
                                                
                                            
                                        </tr>
                                        <?php
                                            $row++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div>
                                    <?php echo $purchases->links();; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/sweetalert2.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/js/jquery.form.min.js"></script>
    <script src="/js/jquery.validate.min.js"></script>
    <script src="/js/sweetalert2.min.js"></script>

    
    <script>
        // function del(e, id, row_id) {
        //     swal({
        //         title: 'Are you sure you want to delete?',
        //         text: 'This process has no return...',
        //         type: 'warning',
        //         showCancelButton: true,
        //         cancelButtonText: 'Cancel',
        //         confirmButtonColor: '#3085d6',
        //         cancelButtonColor: '#d33',
        //         confirmButtonText: 'Delete!'
        //     }).then(function (result) {
        //         if (result.value) {
        //             var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        //             $.ajax({
        //                 type: "Post",
        //                 url: '',
        //                 data: {
        //                     'id': id,
        //                     '_token': CSRF_TOKEN,
        //                     'row_id': row_id
        //                 },
        //                 beforeSubmit: function () {
        //                     //loading
        //                     swal({
        //                         title: '<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i><span class="sr-only">Please wait...</span>',
        //                         text: 'Loading, please wait..',
        //                         showConfirmButton: false
        //                     });
        //                 },
        //                 success: function (response) {
        //                     swal(
        //                         response.title,
        //                         response.content,
        //                         response.case
        //                     );
        //                     if (response.case === 'success') {
        //                         var elem = document.getElementById('row_' + response.row_id);
        //                         elem.parentNode.removeChild(elem);
        //                     }
        //                 }
        //             });
        //         } else {
        //             return false;
        //         }
        //     });
        // }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>