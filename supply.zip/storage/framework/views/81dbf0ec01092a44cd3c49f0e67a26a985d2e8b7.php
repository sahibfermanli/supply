<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div>
            <div class="page-title">
                <div class="title_left" style="width: 100%; !important;">
                    <h3 style="display: inline-block;"> Sifarişlər</h3>
                </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div style="display: <?php echo e($message_display); ?> !important;">
                            <div id="message" class="message-mobile">
                                <h1>Zəhmət olmasa hesab (şirkət) seçin...</h1>
                                <p>Seçim sehifenin sol kenarında, menyudadır...</p>
                            </div>
                        </div>
                        <div class="accounts-mobile">
                            <ul class="nav child_menu show-accounts">
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="account-li" title="<?php echo e($account->account_no); ?>"><a style="color: black !important;" class="account-select" href="/law/pending/orders?account_id=<?php echo e($account->id); ?>"><?php echo e($account->company); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="x_content">
                            <div class="table-responsive">
                                <div style="display: <?php echo e($table_display); ?>;">
                                    <div style="display: inline-block; float: left;">
                                        <form action="" method="post" enctype="multipart/form-data">
                                            <input type="hidden" name="type" value="confirm_account">
                                            <?php echo e(csrf_field()); ?>

                                            
                                            <button title="Sifarişləri təsdiqlə" type="submit" style="background-color: #0e90d2; border-color: #0e90d2; display: inline-block;" class="btn btn-success">Sifarişləri təsdiqlə</button>
                                        </form>
                                    </div>
                                    <a style="display: inline-block; float: right;" class="btn btn-success" title="<?php echo e($orders[0]->account_date); ?>" target="_blank" href="<?php echo e($orders[0]->account_doc); ?>">Hesab: <i class="fa fa-download"></i> <?php echo e($orders[0]->account_no); ?></a>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr class="headings">
                                                <th class="column-title">#</th>
                                                <th class="column-title">Sil</th>
                                                <th class="column-title">Sifarişçi</th>
                                                <th class="column-title">Malın adı </th>
                                                <th class="column-title">Marka </th>
                                                <th class="column-title">Model </th>
                                                <th class="column-title">Miqdar </th>
                                                <th class="column-title">Ölçü vahidi </th>
                                                <th class="column-title">Qiymət </th>
                                                <th class="column-title">Ümumi qiymət </th>
                                                <th class="column-title">Şirkət </th>
                                                
                                                <th class="column-title">Qaimə </th>
                                                <th class="column-title">Fayllar </th>
                                                <th class="column-title">Qəbul edilmə tarixi </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $row = 1;
                                        ?>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $date = date('d.m.Y', strtotime($order->account_date));
                                            ?>
                                            <tr class="even pointer" id="row_<?php echo e($row); ?>">
                                                <td><?php echo e($row); ?></td>
                                                <td id="cancel_<?php echo e($row); ?>">
                                                    <span title="Sifarişi geri çevir" class="btn btn-danger btn-xs" onclick="cancel_order(this, '<?php echo e($order->order_id); ?>', '<?php echo e($order->id); ?>', '<?php echo e($row); ?>');"><i class="fa fa-times"></i></span>
                                                </td>
                                                <td style="min-width: 200px;"><?php echo e($order->name); ?> <?php echo e($order->surname); ?> , <?php echo e($order->Department); ?></td>
                                                <td><?php echo e($order->Product); ?></td>
                                                <td><?php echo e($order->Brend); ?></td>
                                                <td><?php echo e($order->Model); ?></td>
                                                <td><?php echo e($order->pcs); ?></td>
                                                <td><?php echo e($order->Unit); ?></td>
                                                <td><?php echo e($order->cost); ?></td>
                                                <td><?php echo e($order->total_cost); ?></td>
                                                <td title="<?php echo e($order->phone); ?> , <?php echo e($order->address); ?>"><?php echo e($order->company); ?></td>
                                                
                                                    
                                                
                                                <td>
                                                    <?php if(!empty($order->qaime_doc)): ?>
                                                        <a class="btn btn-success btn-xs" title="<?php echo e($order->qaime_date); ?>" target="_blank" href="<?php echo e($order->qaime_doc); ?>"><i class="fa fa-download"></i> <?php echo e($order->qaime_no); ?></a>
                                                    <?php else: ?>
                                                        <span title="Qaimə yoxdur" disabled="true" class="btn btn-warning btn-xs"><i class="fa fa-download"></i></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td style="min-width: 78px;">
                                                    <center>
                                                        <?php if(!empty($order->image)): ?>
                                                            <span title="Şəkli göstər" onclick="get_data('<?php echo e($order->order_id); ?>', 'show_image');" class="btn btn-success btn-xs data-modal"><i class="fa fa-image"></i></span>
                                                        <?php else: ?>
                                                            <span title="Şəkil yoxdur" disabled="true" class="btn btn-success"><i class="fa fa-image"></i></span>
                                                        <?php endif; ?>

                                                        <?php if(!empty($order->deffect_doc)): ?>
                                                            <a style="background-color: #0e90d2;" title="Qüsur aktını endir endir" href="<?php echo e($order->deffect_doc); ?>" class="btn btn-success btn-xs" target="_blank"><i class="fa fa-file"></i></a>
                                                        <?php else: ?>
                                                            <span style="background-color: #0e90d2;" title="Qüsur aktı yoxdur" disabled="true" class="btn btn-success btn-xs"><i class="fa fa-file"></i></span>
                                                        <?php endif; ?>
                                                    </center>
                                                </td>
                                                <td><?php echo e($date); ?></td>
                                            </tr>
                                            <?php
                                                $row++;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="data-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="get-data">

                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/sweetalert2.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/js/jquery.form.min.js"></script>
    <script src="/js/jquery.validate.min.js"></script>
    <script src="/js/sweetalert2.min.js"></script>

    <script>
        $(document).ready(function () {
            $('.show-accounts').css('display', 'block');
        });

        //get data (show image)
        function get_data(id, type) {
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                type: "Post",
                url: '',
                data: {
                    'id': id, //order_id
                    '_token': CSRF_TOKEN,
                    'type': type
                },
                beforeSubmit: function () {
                    //loading
                    swal({
                        title: '<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i><span class="sr-only">Please wait...</span>',
                        text: 'Loading, please wait..',
                        showConfirmButton: false
                    });
                },
                success: function (response) {
                    swal.close();

                    $('.get-data').html(response.data);
                }
            });
        }

        //data (image) modal
        $(document).on('click', '.data-modal', function() {
            $('#data-modal').modal('show');
        });

        //cancel order
        function cancel_order(e, order_id, purchase_id, row_id) {
            swal({
                title: 'Sifarişi geri çevirmək istədiyinizdən əminsiniz?',
                text: 'Bu əməliyyatın geri dönüşü yoxdur...',
                type: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Geri',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Bəli!'
            }).then(function (result) {
                if (result.value) {
                    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                    $.ajax({
                        type: "Post",
                        url: '',
                        data: {
                            'order_id': order_id,
                            'purchase_id': purchase_id,
                            '_token': CSRF_TOKEN,
                            'row_id': row_id,
                            'type': 'cancel_order'
                        },
                        beforeSubmit: function () {
                            //loading
                            swal({
                                title: '<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i><span class="sr-only">Gözləyin...</span>',
                                text: 'Gözləyin, əməliyyat aparılır..',
                                showConfirmButton: false
                            });
                        },
                        success: function (response) {
                            swal(
                                response.title,
                                response.content,
                                response.case
                            );
                            if (response.case === 'success') {
                                $('#cancel_'+response.row_id).html('<span disabled="true" title="Düymə deaktivdir" class="btn btn-danger btn-xs"><i class="fa fa-times"></i></span>');
                            }
                        }
                    });
                } else {
                    return false;
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>